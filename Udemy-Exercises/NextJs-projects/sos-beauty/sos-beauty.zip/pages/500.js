function Custom500() {
    return (
        <div>
            <h1 className="pageHeading">Възникна грешка на сървъра!</h1>
        </div>
    )
}

export default Custom500;