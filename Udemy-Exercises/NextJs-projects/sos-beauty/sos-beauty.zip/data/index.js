export async function allServices() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev.json");
    const data = await response.json();
    
    return data;
}

export async function getMainHeadings() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/imagesAllServices.json");
    const data = await response.json();

    const arr = [];

    for(let key in data) {
        arr.push(data[key]);
    }
    
    return arr;
}

export async function getServiceById(id) {
    const response = await fetch(`https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/${id}.json`);
    const data = await response.json();

    return data;
}

export async function getCosmeticsIds() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics.json");
    const data = await response.json();

    const idsArr = [];

    for (let key in data) {
        idsArr.push(key);
    }

    return idsArr;
}

export async function getCosmeticService() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics.json");
    const cosmetics = await response.json();

    const cosmeticsArray = [];

    for (let key in cosmetics) {
        cosmetics[key].id = key;
        cosmeticsArray.push(cosmetics[key]);
    }

    return cosmeticsArray;
}

export async function getCosmeticServiceById(id) {
    const response = await fetch(`https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics/${id}.json`);
    const data = await response.json();

    return data;
}

export async function getWaxing() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/waxing.json");
    const data = await response.json();

    return data;
}

export async function getManicure() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/manicure.json");
    const data = await response.json();

    return data;
}

export async function getPedicure() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/pedicure.json");
    const data = await response.json();

    return data;
}

export async function getEyelashes() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/eyelashes.json");
    const data = await response.json();

    return data;
}

export async function getAboutUsInfo() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/imagesAboutUsPage.json");
    const data = await response.json();

    return data;
}

export async function getPromotions() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/promotions.json");
    const data = await response.json();

    return Object.values(data);
}

export async function getMicroblading() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/microblading.json");
    const data = await response.json();

    return data;
}

export async function getHairdressing() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/hairdressing.json");
    const data = await response.json();

    return data
}

export async function getDalyFaceTreatments() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/dalyFacialTreatments.json");
    const data = await response.json();

    return data;
}

export async function getContatcsData() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/contacts.json");
    const data = await response.json();

    return data;
}