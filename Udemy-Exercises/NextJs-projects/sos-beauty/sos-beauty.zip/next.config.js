const { PHASE_DEVELOPMENT_SERVER } = require("next/constants");

module.exports = (phase) => {
  if (phase === PHASE_DEVELOPMENT_SERVER) {
    return {
      env: {
        apiKey: process.env.apiKey,
        authDomain: process.env.authDomain,
        databaseURL: process.env.databaseURL,
        projectId: process.env.projectId,
        storageBucket: process.env.storageBucket,
        messagingSenderId: process.env.messagingSenderId,
        appId: process.env.appId,
        currentDevelopmentDatabase: process.env.currentDevelopmentDatabase,
        lat: process.env.lat,
        lng: process.env.lng,
        bootstrapURLKeys: process.env.bootstrapURLKeys
      },
      reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 279, 319, 349, 399, 419, 459, 479, 579, 639, 645, 699, 767, 849, 876, 899, 991, 1023, 1279],
      }
    }
  }

  return {
    env: {
      apiKey: process.env.apiKey,
      authDomain: process.env.authDomain,
      databaseURL: process.env.databaseURL,
      projectId: process.env.projectId,
      storageBucket: process.env.storageBucket,
      messagingSenderId: process.env.messagingSenderId,
      appId: process.env.appId,
      currentProductionDatabase: process.env.currentProductionDatabase,
      currentChineseDatabase: process.env.currentChineseDatabase,
      currentEnglishDatabase: process.env.currentEnglishDatabase,
      lat: process.env.lat,
      lng: process.env.lng,
      bootstrapURLKeys: process.env.bootstrapURLKeys,
      mainDatabaseApp: process.env.mainDatabaseApp,
      currentProductionDatabase: process.env.currentProductionDatabase
    },
    reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 279, 319, 349, 399, 419, 459, 479, 579, 639, 645, 699, 767, 849, 876, 899, 991, 1023, 1279],
      }
  }
}
