const { PHASE_DEVELOPMENT_SERVER } = require("next/constants");

module.exports = (phase) => {
  if (phase === PHASE_DEVELOPMENT_SERVER) {
    return {
      reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 279, 319, 349, 399, 419, 459, 479, 579, 639, 645, 699, 767, 849, 876, 899, 991, 1023, 1279],
      }
    }
  }

  return {
    reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 279, 319, 349, 399, 419, 459, 479, 579, 639, 645, 699, 767, 849, 876, 899, 991, 1023, 1279],
      }
  }
}
