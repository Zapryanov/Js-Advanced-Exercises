(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7836:
/***/ ((module) => {

// Exports
module.exports = {
	"see-more": "footer-button_see-more__4b_At",
	"inset-shadow": "footer-button_inset-shadow__W_YBh",
	"see-more-text": "footer-button_see-more-text__i2CMJ"
};


/***/ }),

/***/ 2248:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-image": "footer-image-link_wrap-image__adoNL",
	"image": "footer-image-link_image__b0dNQ"
};


/***/ }),

/***/ 7856:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__57EcY",
	"each-footer-block": "footer_each-footer-block__lV_OK",
	"contacts": "footer_contacts__nW_VK",
	"wrap-socials": "footer_wrap-socials__IW75W"
};


/***/ }),

/***/ 1055:
/***/ ((module) => {

// Exports
module.exports = {
	"main-header": "main-header_main-header__DARnG",
	"salon": "main-header_salon__fhSME",
	"menu": "main-header_menu__5RM0m",
	"link-menu": "main-header_link-menu__ga7TG",
	"promotions-button": "main-header_promotions-button__DP9ew",
	"social-icons": "main-header_social-icons__H36mL",
	"link-phone": "main-header_link-phone__M9_0d",
	"phone": "main-header_phone__MHW4m",
	"socials-header": "main-header_socials-header__6aUMc",
	"main-menu": "main-header_main-menu___cyub",
	"phone-image": "main-header_phone-image__4_SWV"
};


/***/ }),

/***/ 2278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/layout/footer.module.css
var footer_module = __webpack_require__(7856);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/buttons/footer-button.module.css
var footer_button_module = __webpack_require__(7836);
var footer_button_module_default = /*#__PURE__*/__webpack_require__.n(footer_button_module);
;// CONCATENATED MODULE: ./components/buttons/footer-button.js



function FooterButton({ link  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (footer_button_module_default())["see-more"],
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (footer_button_module_default())["inset-shadow"],
            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: link,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (footer_button_module_default())["see-more-text"],
                    target: "_blank",
                    children: "виж повече"
                })
            })
        })
    }));
}
/* harmony default export */ const footer_button = (FooterButton);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/imageLinks/footer-image-link.module.css
var footer_image_link_module = __webpack_require__(2248);
var footer_image_link_module_default = /*#__PURE__*/__webpack_require__.n(footer_image_link_module);
;// CONCATENATED MODULE: ./components/imageLinks/footer-image-link.js




function FooterImageLink({ link , image  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: link,
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            className: (footer_image_link_module_default())["wrap-image"],
            target: "_blank",
            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                className: (footer_image_link_module_default()).image,
                width: 280,
                height: 175,
                src: image,
                alt: "google-map"
            })
        })
    }));
}
/* harmony default export */ const footer_image_link = (FooterImageLink);

;// CONCATENATED MODULE: ./components/layout/footer.js




function Footer() {
    const obj = {
        googleLink: "https://www.google.com/maps/place/S.O.S+Beauty/@42.137649,24.7864931,19z/data=!4m5!3m4!1s0x14acd1671feabfcf:0xbe40cf6f6dab0e16!8m2!3d42.137649!4d24.7870403",
        googleImage: "/images/google-map-smallest.jpg",
        facebookLink: "https://www.facebook.com/S.O.SBeauti",
        facebookImage: "/images/facebook.jpg"
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (footer_module_default()).footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footer_module_default())["each-footer-block"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Контакти"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).contacts,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                children: [
                                    "GSM:\xa0",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "tel:+35976862629",
                                        children: "0876 862 629"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "гр. Пловдив"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Комплекс - \"Олимпия\""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "ул. \"Георги Данчов\" - 46"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "/ Срещу входа на Акваленд /"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(footer_module_default())["each-footer-block"]}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Google Map"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default())["wrap-socials"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(footer_button, {
                                className: (footer_module_default()).left,
                                link: obj.googleLink
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(footer_image_link, {
                                link: obj.googleLink,
                                image: obj.googleImage
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(footer_module_default())["each-footer-block"]}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Facebook"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default())["wrap-socials"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(footer_button, {
                                className: (footer_module_default()).left,
                                link: obj.facebookLink
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(footer_image_link, {
                                link: obj.facebookLink,
                                image: obj.facebookImage
                            })
                        ]
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const footer = (Footer);

// EXTERNAL MODULE: ./components/layout/main-header.module.css
var main_header_module = __webpack_require__(1055);
var main_header_module_default = /*#__PURE__*/__webpack_require__.n(main_header_module);
;// CONCATENATED MODULE: ./components/layout/main-header.js




function MainHeader() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: (main_header_module_default())["main-header"],
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "S.O.S Beauty"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (main_header_module_default()).salon,
                        children: "Beauty Salon"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: `${(main_header_module_default()).menu} ${(main_header_module_default())["main-menu"]}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (main_header_module_default())["link-menu"],
                                        children: "Услуги"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/about",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (main_header_module_default())["link-menu"],
                                        children: "За нас"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (main_header_module_default())["promotions-button"],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/promotions",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (main_header_module_default())["link-menu"],
                                        children: "Промоции"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/contacts",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (main_header_module_default())["link-menu"],
                                        children: "Контакти"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: `${(main_header_module_default()).menu} ${(main_header_module_default())["socials-header"]}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "https://www.facebook.com/S.O.SBeauti/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `${(main_header_module_default())["link-menu"]} ${(main_header_module_default())["facebook-icon"]} ${(main_header_module_default())["social-icons"]}`,
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            width: 20,
                                            height: 20,
                                            src: "/images/facebook-3d.png",
                                            alt: "facebook"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "tel:+359876862629",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: `${(main_header_module_default())["link-menu"]} ${(main_header_module_default())["link-phone"]} ${(main_header_module_default())["social-icons"]}`,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (main_header_module_default())["phone-image"],
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    width: 20,
                                                    height: 20,
                                                    src: "/images/phone.png",
                                                    alt: "phone"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (main_header_module_default()).phone,
                                                children: "0876 862 629"
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const main_header = (MainHeader);

;// CONCATENATED MODULE: ./components/layout/layout.js



function Layout(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(main_header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: props.children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    }));
}
/* harmony default export */ const layout = (Layout);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/_app.js




function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "viewport",
                    content: "initial-scale=1.0, width=device-width"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,676,664], () => (__webpack_exec__(2278)));
module.exports = __webpack_exports__;

})();