(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 5645:
/***/ ((module) => {

// Exports
module.exports = {
	"service-item": "service-item_service-item__pl8fO",
	"wrap-main-name": "service-item_wrap-main-name__atSfR",
	"wrap-secondary-name": "service-item_wrap-secondary-name__pK4kR",
	"country": "service-item_country__PTVBZ",
	"img": "service-item_img__Xi8X7",
	"wrap-image-service": "service-item_wrap-image-service__PdbJR",
	"wrap-btn-service": "service-item_wrap-btn-service__YUSaR",
	"btn-service": "service-item_btn-service__REon6"
};


/***/ }),

/***/ 657:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-all-services": "services-list_wrap-all-services__U4vCG"
};


/***/ }),

/***/ 9605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/services/service-item.module.css
var service_item_module = __webpack_require__(5645);
var service_item_module_default = /*#__PURE__*/__webpack_require__.n(service_item_module);
;// CONCATENATED MODULE: ./components/services/service-item.js




function ServiceItem(props) {
    let { id , image , titleBig , titleSmall , country  } = props;
    switch(titleBig){
        case "Козметика":
            id = "cosmetics";
            break;
        case "Маникюр":
            id = "manicure";
            break;
        case "Педикюр":
            id = "pedicure";
            break;
        case "Миглопластика":
            id = "eyelashes";
            break;
        case "Кола Маска":
            id = "waxing";
            break;
        case "Микроблейдинг":
            id = "microblading";
            break;
        case "Фризьорство":
            id = "hairdressing";
            break;
        case "Ежедневни процедури за лице":
            id = "dalyFacialTreatments";
            break;
        default:
            break;
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: (service_item_module_default())["service-item"],
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (service_item_module_default())["wrap-main-name"],
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: titleBig
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (service_item_module_default())["wrap-secondary-name"],
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                            children: [
                                titleSmall,
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (service_item_module_default()).country,
                                    children: country
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (service_item_module_default())["wrap-image-service"],
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    className: (service_item_module_default()).img,
                    width: 500,
                    height: 400,
                    src: image,
                    alt: titleBig
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (service_item_module_default())["wrap-btn-service"],
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: `/${id}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (service_item_module_default())["btn-service"],
                        children: "Виж повече"
                    })
                })
            })
        ]
    }, id));
}
/* harmony default export */ const service_item = (ServiceItem);

// EXTERNAL MODULE: ./components/services/services-list.module.css
var services_list_module = __webpack_require__(657);
var services_list_module_default = /*#__PURE__*/__webpack_require__.n(services_list_module);
;// CONCATENATED MODULE: ./components/services/services-list.js



function ServicesList(props) {
    const { services  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: (services_list_module_default())["wrap-all-services"],
        children: services.map((service, id)=>/*#__PURE__*/ jsx_runtime_.jsx(service_item, {
                id: id,
                titleBig: service.titleBig,
                titleSmall: service.titleSmall,
                country: service.country,
                image: service.image,
                price: service.price,
                generalInfo: service.generalInfo,
                serviceDescription: service.serviceDescription
            }, id)
        )
    }));
}
/* harmony default export */ const services_list = (ServicesList);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./data/index.js
var data = __webpack_require__(3820);
;// CONCATENATED MODULE: ./pages/index.js




function HomePage(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "S.O.S Beauty - Салон за красота Пловдив"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Салон за красота. Маникюр, педикюр, ноктопластика, кола маска, козметика, почистване на лице, миглопластика"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "pageHeading",
                children: "Услуги"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(services_list, {
                services: props.loadedServices
            })
        ]
    }));
}
async function getStaticProps() {
    const mainHeadings = await (0,data/* getMainHeadings */.TL)();
    return {
        props: {
            loadedServices: mainHeadings
        },
        revalidate: 1800
    };
}
/* harmony default export */ const pages = (HomePage);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,676,664,331], () => (__webpack_exec__(9605)));
module.exports = __webpack_exports__;

})();