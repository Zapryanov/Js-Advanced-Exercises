(() => {
var exports = {};
exports.id = 27;
exports.ids = [27];
exports.modules = {

/***/ 1735:
/***/ ((module) => {

// Exports
module.exports = {
	"cosmetics-item": "cosmetics-item_cosmetics-item__XQXtV",
	"img": "cosmetics-item_img__LSDuD",
	"wrap-headings": "cosmetics-item_wrap-headings__WpzvM",
	"wrap-main-name": "cosmetics-item_wrap-main-name__ldo5f",
	"wrap-secondary-name": "cosmetics-item_wrap-secondary-name__ONgSE",
	"shine": "cosmetics-item_shine__yTk5B",
	"wrap-image-cosmetics": "cosmetics-item_wrap-image-cosmetics__mummI",
	"wrap-btn-cosmetics": "cosmetics-item_wrap-btn-cosmetics__rsiE2",
	"btn-cosmetics": "cosmetics-item_btn-cosmetics__fMone"
};


/***/ }),

/***/ 2165:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-all-cosmetics": "cosmetics-list_wrap-all-cosmetics__GwOba"
};


/***/ }),

/***/ 174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ cosmetics),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/cosmetics/cosmetics-item.module.css
var cosmetics_item_module = __webpack_require__(1735);
var cosmetics_item_module_default = /*#__PURE__*/__webpack_require__.n(cosmetics_item_module);
;// CONCATENATED MODULE: ./components/cosmetics/cosmetics-item.js




function CosmeticItem(props) {
    let { id , image , titleBig , titleSmall  } = props;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: (cosmetics_item_module_default())["cosmetics-item"],
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (cosmetics_item_module_default())["wrap-headings"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (cosmetics_item_module_default())["wrap-main-name"],
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: titleBig
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (cosmetics_item_module_default())["wrap-secondary-name"],
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: titleSmall
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (cosmetics_item_module_default())["wrap-image-cosmetics"],
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    className: (cosmetics_item_module_default()).img,
                    width: 300,
                    height: 220,
                    src: image,
                    alt: titleBig
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (cosmetics_item_module_default())["wrap-btn-cosmetics"],
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: `/cosmetics/${id}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (cosmetics_item_module_default())["btn-cosmetics"],
                        children: "Виж повече"
                    })
                })
            })
        ]
    }, id));
}
/* harmony default export */ const cosmetics_item = (CosmeticItem);

// EXTERNAL MODULE: ./components/cosmetics/cosmetics-list.module.css
var cosmetics_list_module = __webpack_require__(2165);
var cosmetics_list_module_default = /*#__PURE__*/__webpack_require__.n(cosmetics_list_module);
;// CONCATENATED MODULE: ./components/cosmetics/cosmetics-list.js



function CosmeticsList(props) {
    const { services  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: (cosmetics_list_module_default())["wrap-all-cosmetics"],
        children: services.map((service)=>/*#__PURE__*/ jsx_runtime_.jsx(cosmetics_item, {
                id: service.id,
                titleBig: service.titleBig,
                titleSmall: service.titleSmall,
                image: service.image
            }, service.id)
        )
    }));
}
/* harmony default export */ const cosmetics_list = (CosmeticsList);

// EXTERNAL MODULE: ./data/index.js
var data = __webpack_require__(3820);
;// CONCATENATED MODULE: ./pages/cosmetics/index.js




function CosmeticsPage(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "S.O.S Beauty - Козметика"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Козметика за лице на френската професионална козметика DR-Renaud и на IROHA"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "pageHeading",
                children: "Козметика"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(cosmetics_list, {
                services: props.cosmetics
            })
        ]
    }));
}
async function getStaticProps() {
    const cosmeticsArray = await (0,data/* getCosmeticService */.Uh)();
    if (!cosmeticsArray) {
        return {
            redirect: {
                destination: "/",
                permanent: false
            }
        };
    }
    return {
        props: {
            cosmetics: cosmeticsArray
        },
        revalidate: 1800
    };
}
/* harmony default export */ const cosmetics = (CosmeticsPage);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,676,664,331], () => (__webpack_exec__(174)));
module.exports = __webpack_exports__;

})();