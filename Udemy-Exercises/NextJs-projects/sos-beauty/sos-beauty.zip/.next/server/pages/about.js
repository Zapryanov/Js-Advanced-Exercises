(() => {
var exports = {};
exports.id = 521;
exports.ids = [521];
exports.modules = {

/***/ 324:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "about_wrapper__rddGX",
	"top-center": "about_top-center__hIXZY",
	"main-description": "about_main-description__kVfRm",
	"wrap-images-brands": "about_wrap-images-brands__9WdxM",
	"wrap-images-of-products": "about_wrap-images-of-products__iLE6j",
	"image-of-product": "about_image-of-product__s9_w6",
	"wrap-text-and-images": "about_wrap-text-and-images__FNAk6",
	"wrap-text": "about_wrap-text__sE_ve",
	"wrap-images": "about_wrap-images__X15FY",
	"remove-space": "about_remove-space__z8alR",
	"current-image": "about_current-image__0ih_E",
	"about-us-image": "about_about-us-image___zUTN"
};


/***/ }),

/***/ 8051:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3820);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(324);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_3__);





function About(props) {
    const mainInfo = props.aboutUsMainInfo;
    const brandsLogos = props.brands;
    const topCenterText = props.mainText;
    const realCosmetics = props.realCosmetics;
    const realCosmeticsArr = [];
    for(let key in realCosmetics){
        const innerObject = realCosmetics[key];
        for(let key2 in innerObject){
            realCosmeticsArr.push(innerObject[key2]);
        }
    }
    const objEntriesBrands = Object.entries(brandsLogos);
    const objEntriesMainInfo = Object.entries(mainInfo);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "За нас | салон за красота S.O.S-Beauty"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Маникюр, педикюр, ноктопластика, гел лак, кола маска, микроблейдинг, почистване и терапии за лице Пловдив, Тракия, до Акваленд"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "pageHeading",
                children: "За нас"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default().wrapper),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["top-center"]),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["main-description"]),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: topCenterText
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-images-brands"]),
                                children: objEntriesBrands.map((eachBrand, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                            width: eachBrand[1].width,
                                            height: eachBrand[1].height,
                                            src: eachBrand[1].image,
                                            alt: eachBrand[1].alt
                                        })
                                    }, i)
                                )
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-images-of-products"]),
                                children: realCosmeticsArr.map((obj, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            margin: obj.margin
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["image-of-product"]),
                                            src: obj.image,
                                            width: obj.width,
                                            height: obj.height,
                                            alt: obj.alt
                                        })
                                    }, i)
                                )
                            })
                        ]
                    }),
                    objEntriesMainInfo.map((eachService, i)=>{
                        if (i % 2 === 0) {
                            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-text-and-images"]),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-text"]),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                children: eachService[1].heading
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: eachService[1].description
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-images"]),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["remove-space"]),
                                            children: eachService[1].images.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["current-image"]),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                        className: "img",
                                                        width: 200,
                                                        height: 150,
                                                        src: image,
                                                        alt: "nails"
                                                    })
                                                }, index)
                                            )
                                        })
                                    })
                                ]
                            }, i));
                        } else {
                            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-text-and-images"]),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-images"]),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["remove-space"]),
                                            children: eachService[1].images.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["current-image"]),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default().img),
                                                        width: 200,
                                                        height: 150,
                                                        src: image,
                                                        alt: "nails"
                                                    })
                                                }, index)
                                            )
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-text"]),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                children: eachService[1].heading
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: eachService[1].description
                                            })
                                        ]
                                    })
                                ]
                            }, i));
                        }
                    })
                ]
            })
        ]
    }));
}
async function getStaticProps() {
    const aboutUsInfo = await (0,_data__WEBPACK_IMPORTED_MODULE_4__/* .getAboutUsInfo */ .$h)();
    const infoMainServices = aboutUsInfo.infoServices;
    const brandsImages = aboutUsInfo.brands;
    const topText = aboutUsInfo.topText;
    const cosmeticsFromTheBrand = aboutUsInfo.cosmeticsFromTheBrand;
    if (!infoMainServices || !brandsImages || !topText || !cosmeticsFromTheBrand) {
        return {
            notFound: true
        };
    }
    return {
        props: {
            aboutUsMainInfo: infoMainServices,
            brands: brandsImages,
            mainText: topText,
            realCosmetics: cosmeticsFromTheBrand
        },
        revalidate: 1800
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);


/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,331], () => (__webpack_exec__(8051)));
module.exports = __webpack_exports__;

})();