(() => {
var exports = {};
exports.id = 911;
exports.ids = [911];
exports.modules = {

/***/ 3376:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-women-and-men": "waxing_wrap-women-and-men__bDtmH",
	"section-human": "waxing_section-human__cGadA",
	"h2-waxing": "waxing_h2-waxing__yhhcQ"
};


/***/ }),

/***/ 3735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_prices_prices_list__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4775);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3820);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3376);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_3__);





function WaxingPage(props) {
    const { men , women  } = props.prices;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Кола Маска | салон за красота S.O.S-Beauty"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Кола маска ръце, кола маска крака, кола маска мишници в Пловдив, Тракия, до Акваленд"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "pageHeading",
                children: "Кола Маска"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["wrap-women-and-men"]),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["section-human"]),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["h2-waxing"]),
                                children: "Жени"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_prices_prices_list__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                prices: women
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["section-human"]),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: (_index_module_css__WEBPACK_IMPORTED_MODULE_3___default()["h2-waxing"]),
                                children: "Мъже"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_prices_prices_list__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                prices: men
                            })
                        ]
                    })
                ]
            })
        ]
    }));
}
async function getStaticProps() {
    const manAndWomenPrices = await (0,_data__WEBPACK_IMPORTED_MODULE_4__/* .getWaxing */ .KD)();
    if (!manAndWomenPrices) {
        return {
            notFound: true
        };
    }
    return {
        props: {
            prices: manAndWomenPrices
        },
        revalidate: 1800
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WaxingPage);


/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [331,775], () => (__webpack_exec__(3735)));
module.exports = __webpack_exports__;

})();