exports.id = 775;
exports.ids = [775];
exports.modules = {

/***/ 597:
/***/ ((module) => {

// Exports
module.exports = {
	"li-price-item": "prices-item_li-price-item__IuMhh",
	"part": "prices-item_part__XEyGW",
	"price": "prices-item_price__m_1_A"
};


/***/ }),

/***/ 4406:
/***/ ((module) => {

// Exports
module.exports = {
	"odd-or-even": "prices-list_odd-or-even__lkBaR"
};


/***/ }),

/***/ 4775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ prices_list)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/prices/prices-item.module.css
var prices_item_module = __webpack_require__(597);
var prices_item_module_default = /*#__PURE__*/__webpack_require__.n(prices_item_module);
;// CONCATENATED MODULE: ./components/prices/prices-item.js


function PricesItem(props) {
    const { id , part , price  } = props;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: (prices_item_module_default())["li-price-item"],
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: (prices_item_module_default()).part,
                children: part
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: (prices_item_module_default()).price,
                children: [
                    price,
                    " лв"
                ]
            })
        ]
    }, id));
}
/* harmony default export */ const prices_item = (PricesItem);

// EXTERNAL MODULE: ./components/prices/prices-list.module.css
var prices_list_module = __webpack_require__(4406);
var prices_list_module_default = /*#__PURE__*/__webpack_require__.n(prices_list_module);
;// CONCATENATED MODULE: ./components/prices/prices-list.js



function PricesList(props) {
    const { prices  } = props;
    const data = Object.entries(prices);
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: (prices_list_module_default())["wrap-ul"],
        children: data.map((human, id)=>/*#__PURE__*/ jsx_runtime_.jsx(prices_item, {
                id: id,
                part: human[0],
                price: human[1]
            }, id)
        )
    }));
}
/* harmony default export */ const prices_list = (PricesList);


/***/ })

};
;