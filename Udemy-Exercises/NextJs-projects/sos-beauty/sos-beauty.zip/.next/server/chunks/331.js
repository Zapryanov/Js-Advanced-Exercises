"use strict";
exports.id = 331;
exports.ids = [331];
exports.modules = {

/***/ 3820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TL": () => (/* binding */ getMainHeadings),
/* harmony export */   "uP": () => (/* binding */ getCosmeticsIds),
/* harmony export */   "Uh": () => (/* binding */ getCosmeticService),
/* harmony export */   "Xm": () => (/* binding */ getCosmeticServiceById),
/* harmony export */   "KD": () => (/* binding */ getWaxing),
/* harmony export */   "t1": () => (/* binding */ getManicure),
/* harmony export */   "am": () => (/* binding */ getPedicure),
/* harmony export */   "X9": () => (/* binding */ getEyelashes),
/* harmony export */   "$h": () => (/* binding */ getAboutUsInfo),
/* harmony export */   "Fh": () => (/* binding */ getPromotions),
/* harmony export */   "iT": () => (/* binding */ getMicroblading),
/* harmony export */   "Ih": () => (/* binding */ getHairdressing),
/* harmony export */   "wp": () => (/* binding */ getDalyFaceTreatments),
/* harmony export */   "dh": () => (/* binding */ getContatcsData)
/* harmony export */ });
/* unused harmony exports allServices, getServiceById */
async function allServices() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev.json");
    const data = await response.json();
    return data;
}
async function getMainHeadings() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/imagesAllServices.json");
    const data = await response.json();
    const arr = [];
    for(let key in data){
        arr.push(data[key]);
    }
    return arr;
}
async function getServiceById(id) {
    const response = await fetch(`https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/${id}.json`);
    const data = await response.json();
    return data;
}
async function getCosmeticsIds() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics.json");
    const data = await response.json();
    const idsArr = [];
    for(let key in data){
        idsArr.push(key);
    }
    return idsArr;
}
async function getCosmeticService() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics.json");
    const cosmetics = await response.json();
    const cosmeticsArray = [];
    for(let key in cosmetics){
        cosmetics[key].id = key;
        cosmeticsArray.push(cosmetics[key]);
    }
    return cosmeticsArray;
}
async function getCosmeticServiceById(id) {
    const response = await fetch(`https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/cosmetics/${id}.json`);
    const data = await response.json();
    return data;
}
async function getWaxing() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/waxing.json");
    const data = await response.json();
    return data;
}
async function getManicure() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/manicure.json");
    const data = await response.json();
    return data;
}
async function getPedicure() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/pedicure.json");
    const data = await response.json();
    return data;
}
async function getEyelashes() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/eyelashes.json");
    const data = await response.json();
    return data;
}
async function getAboutUsInfo() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/imagesAboutUsPage.json");
    const data = await response.json();
    return data;
}
async function getPromotions() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/promotions.json");
    const data = await response.json();
    return Object.values(data);
}
async function getMicroblading() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/microblading.json");
    const data = await response.json();
    return data;
}
async function getHairdressing() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/hairdressing.json");
    const data = await response.json();
    return data;
}
async function getDalyFaceTreatments() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/dalyFacialTreatments.json");
    const data = await response.json();
    return data;
}
async function getContatcsData() {
    const response = await fetch("https://sos-beauty-f7b87-default-rtdb.europe-west1.firebasedatabase.app/services-dev/contacts.json");
    const data = await response.json();
    return data;
}


/***/ })

};
;