exports.id = 65;
exports.ids = [65];
exports.modules = {

/***/ 1831:
/***/ ((module) => {

// Exports
module.exports = {
	"leaf-effect": "big-button_leaf-effect__DrAE_"
};


/***/ }),

/***/ 7758:
/***/ ((module) => {

// Exports
module.exports = {
	"lesson-container": "lesson-item_lesson-container__ECstb",
	"title-lesson": "lesson-item_title-lesson__4a0k5",
	"wrap-image": "lesson-item_wrap-image__mHMao",
	"image": "lesson-item_image__0iwmt",
	"text-lesson": "lesson-item_text-lesson__z6p4g",
	"btn-lesson": "lesson-item_btn-lesson__oCyDU"
};


/***/ }),

/***/ 2183:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-all-lessons": "lesson-list_wrap-all-lessons__zBy4T"
};


/***/ }),

/***/ 826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1831);
/* harmony import */ var _index_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_css__WEBPACK_IMPORTED_MODULE_2__);



function BigButton() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_css__WEBPACK_IMPORTED_MODULE_2___default()["leaf-effect"]),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            href: "https://www.facebook.com/MravkaZanimavka",
            target: "__blank",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                width: 1123,
                height: 200,
                src: "/images/save-lesson.png",
                alt: "link-facebook"
            })
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BigButton);


/***/ }),

/***/ 8065:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ all_lessons_page_component)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "sanitize-html"
var external_sanitize_html_ = __webpack_require__(6109);
var external_sanitize_html_default = /*#__PURE__*/__webpack_require__.n(external_sanitize_html_);
// EXTERNAL MODULE: ./data/getData.js
var getData = __webpack_require__(8546);
// EXTERNAL MODULE: ./components/lessons/lesson-item.module.css
var lesson_item_module = __webpack_require__(7758);
var lesson_item_module_default = /*#__PURE__*/__webpack_require__.n(lesson_item_module);
;// CONCATENATED MODULE: ./components/lessons/lesson-item.js






function LessonItem(props) {
    const { id , language , image , title , text  } = props;
    const clean = external_sanitize_html_default()(text, getData/* sanitizeObj */.OV);
    let exploreLink = "";
    if (language === "Китайски") {
        exploreLink = `/lessons/chineseLessons/${id}`;
    } else if (language === "Английски") {
        exploreLink = `/lessons/englishLessons/${id}`;
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
        className: (lesson_item_module_default())["lesson-container"],
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: (lesson_item_module_default())["title-lesson"],
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (lesson_item_module_default())["wrap-image"],
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    className: (lesson_item_module_default()).image,
                    width: 1200,
                    height: 750,
                    src: image,
                    alt: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (lesson_item_module_default())["text-lesson"],
                dangerouslySetInnerHTML: {
                    __html: clean
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: exploreLink,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (lesson_item_module_default())["btn-lesson"],
                    children: "Виж повече"
                })
            })
        ]
    }, id));
}
/* harmony default export */ const lesson_item = (LessonItem);

// EXTERNAL MODULE: ./components/lessons/lesson-list.module.css
var lesson_list_module = __webpack_require__(2183);
var lesson_list_module_default = /*#__PURE__*/__webpack_require__.n(lesson_list_module);
;// CONCATENATED MODULE: ./components/lessons/lesson-list.js



function LessonList(props) {
    const { lessons  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (lesson_list_module_default())["wrap-all-lessons"],
        children: lessons.map((lesson)=>/*#__PURE__*/ jsx_runtime_.jsx(lesson_item, {
                language: lesson.language,
                id: lesson.id,
                title: lesson.title,
                image: lesson.image,
                text: lesson.text
            }, lesson.id)
        )
    }));
}
/* harmony default export */ const lesson_list = (LessonList);

// EXTERNAL MODULE: ./components/big-button/index.js
var big_button = __webpack_require__(826);
;// CONCATENATED MODULE: ./components/lessons/all-lessons-page-component.js




function AllLessonsPageComponent({ language , lessons , url  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            "Уроци-",
                            language
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: `уроци по ${language} за деца с мравка занимавка в град Пловдив`
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                children: [
                    "Учим ",
                    language
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(lesson_list, {
                lessons: lessons
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(big_button/* default */.Z, {})
        ]
    }));
}
/* harmony default export */ const all_lessons_page_component = (AllLessonsPageComponent);


/***/ })

};
;