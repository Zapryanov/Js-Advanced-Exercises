exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 7698:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-current-lesson": "current-lesson-component_wrap-current-lesson__2LyPY",
	"width-line": "current-lesson-component_width-line__J5MdR",
	"wrap-image": "current-lesson-component_wrap-image__GqGU2",
	"image-lesson": "current-lesson-component_image-lesson__NzLhN",
	"box-shadow": "current-lesson-component_box-shadow__XH0fS",
	"text": "current-lesson-component_text__oCb92",
	"wrap-buttons": "current-lesson-component_wrap-buttons__YNmed",
	"btn-lesson": "current-lesson-component_btn-lesson__J6Fg8"
};


/***/ }),

/***/ 9915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7698);
/* harmony import */ var _current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4__);





function CurrentLessonComponent({ language , title , image , cleanText , goBackFunc  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: `Урок по ${language} за деца в град Пловдив, на тема - ${title}`
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                className: (_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["wrap-current-lesson"]),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: (_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["width-line"]),
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["width-line"])} ${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["wrap-image"])}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            className: `${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["image-lesson"])} ${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["box-shadow"])}`,
                            width: 1200,
                            height: 800,
                            src: image,
                            alt: title
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["width-line"])} ${(_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default().text)}`,
                        dangerouslySetInnerHTML: {
                            __html: cleanText.props.text
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["wrap-buttons"]),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: (_current_lesson_component_module_css__WEBPACK_IMPORTED_MODULE_4___default()["btn-lesson"]),
                            onClick: goBackFunc,
                            children: "Назад"
                        })
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrentLessonComponent);


/***/ })

};
;