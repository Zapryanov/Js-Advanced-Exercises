"use strict";
exports.id = 546;
exports.ids = [546];
exports.modules = {

/***/ 8546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lS": () => (/* binding */ getAllChineseLessons),
/* harmony export */   "HI": () => (/* binding */ getCurrentChineseLesson),
/* harmony export */   "Oz": () => (/* binding */ getAllEnglishLessons),
/* harmony export */   "Xv": () => (/* binding */ getCurrentEnglishLesson),
/* harmony export */   "K0": () => (/* binding */ getContactsInfo),
/* harmony export */   "YG": () => (/* binding */ getImagesMainPage),
/* harmony export */   "OV": () => (/* binding */ sanitizeObj)
/* harmony export */ });
async function getAllChineseLessons() {
    try {
        const res = await fetch(`${process.env.databaseUrl}/${"lessons"}/${"chineseLessons"}.json`);
        const data = await res.json();
        const loadedLessons = [];
        for(const key in data){
            loadedLessons.push({
                id: key,
                ...data[key]
            });
        }
        return loadedLessons.reverse();
    } catch (err) {
        console.error(err);
    }
}
async function getCurrentChineseLesson(id) {
    const allLessons = await getAllChineseLessons();
    const currentLesson = allLessons.find((lesson)=>lesson.id === id
    );
    return currentLesson;
}
async function getAllEnglishLessons() {
    try {
        const res = await fetch(`${process.env.databaseUrl}/${"lessons"}/${"englishLessons"}.json`);
        const data = await res.json();
        const loadedLessons = [];
        for(const key in data){
            loadedLessons.push({
                id: key,
                ...data[key]
            });
        }
        return loadedLessons.reverse();
    } catch (err) {
        console.error(err);
    }
}
async function getCurrentEnglishLesson(id) {
    const allLessons = await getAllEnglishLessons();
    const currentLesson = allLessons.find((lesson)=>lesson.id === id
    );
    return currentLesson;
}
async function getContactsInfo() {
    const response = await fetch(`${process.env.databaseUrl}/${"lessons"}/contacts.json`);
    const data = await response.json();
    return data;
}
async function getImagesMainPage() {
    const response = await fetch(`${process.env.databaseUrl}/${"lessons"}/iconsMainPage.json`);
    const data = await response.json();
    return data;
}
const sanitizeObj = {
    allowedTags: [
        'br',
        'b',
        'i',
        'em',
        'span',
        'strong',
        'a',
        'p',
        'div',
        'h1',
        'h2',
        'h3',
        'ul',
        'li'
    ],
    allowedAttributes: {
        'a': [
            'href'
        ]
    },
    selfClosing: [
        'br',
        'hr',
        'link'
    ]
};


/***/ })

};
;