(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7856:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__57EcY",
	"wrap-footer-content": "footer_wrap-footer-content__9hc2v",
	"space-vertically": "footer_space-vertically__I3k6O",
	"position-icon": "footer_position-icon__J6yXO",
	"space-left": "footer_space-left__Lz1BO",
	"hyper-link": "footer_hyper-link__SUopK"
};


/***/ }),

/***/ 5425:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "header_header__pxdB1",
	"nav-link": "header_nav-link__sqkTn",
	"logo": "header_logo__Epne3"
};


/***/ }),

/***/ 3911:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "layout_container__ithU7",
	"main": "layout_main__i6bTv"
};


/***/ }),

/***/ 7638:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-spinner": "loading_wrap-spinner__V37YT",
	"lds-dual-ring": "loading_lds-dual-ring___NRb9"
};


/***/ }),

/***/ 8341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/layout/footer.module.css
var footer_module = __webpack_require__(7856);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
;// CONCATENATED MODULE: ./components/layout/footer.js




function Footer() {
    return(/*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (footer_module_default()).footer,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (footer_module_default())["wrap-footer-content"],
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (footer_module_default())["space-vertically"],
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "https://www.facebook.com/MravkaZanimavka",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: `${(footer_module_default())["position-icon"]} ${(footer_module_default())["hyper-link"]}`,
                                target: "_blank",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        width: 20,
                                        height: 20,
                                        src: "/images/facebook.png",
                                        alt: "facebook-icon"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (footer_module_default())["space-left"],
                                        children: "Мравка Занимавка"
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (footer_module_default())["space-vertically"],
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/contacts",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: `${(footer_module_default())["position-icon"]} ${(footer_module_default())["hyper-link"]}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        width: 20,
                                        height: 20,
                                        src: "/images/phone.png",
                                        alt: "contacts"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (footer_module_default())["space-left"],
                                        children: "Контакти"
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (footer_module_default())["space-vertically"],
                    children: "Created by Ivan Zapryanov"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (footer_module_default())["space-vertically"],
                    children: "\xa9 2022 Next-Js-Power"
                })
            ]
        })
    }));
}
/* harmony default export */ const footer = (Footer);

// EXTERNAL MODULE: ./components/layout/header.module.css
var header_module = __webpack_require__(5425);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
;// CONCATENATED MODULE: ./components/layout/header.js




function Header() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: (header_module_default()).header,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (header_module_default()).logo,
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            width: 150,
                            height: 150,
                            src: "/images/logo.png",
                            alt: "logo"
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: (header_module_default()).nav,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (header_module_default())["nav-link"],
                                    children: "Мравка Занимавка"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/lessons/chineseLessons",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (header_module_default())["nav-link"],
                                    children: "Учим китайски"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/lessons/englishLessons",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (header_module_default())["nav-link"],
                                    children: "Учим английски"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/contacts",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (header_module_default())["nav-link"],
                                    children: "Контакти"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    }));
}
/* harmony default export */ const header = (Header);

// EXTERNAL MODULE: ./components/layout/layout.module.css
var layout_module = __webpack_require__(3911);
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);
;// CONCATENATED MODULE: ./components/layout/layout.js




function Layout(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (layout_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (layout_module_default()).main,
                children: props.children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    }));
}
/* harmony default export */ const layout = (Layout);

// EXTERNAL MODULE: ./components/loading/index.module.css
var index_module = __webpack_require__(7638);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
;// CONCATENATED MODULE: ./components/loading/index.js


function Loading() {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (index_module_default())["wrap-spinner"],
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (index_module_default())["lds-dual-ring"]
        })
    }));
}
/* harmony default export */ const components_loading = (Loading);

;// CONCATENATED MODULE: ./pages/_app.js







function MyApp({ Component , pageProps  }) {
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    router_.Router.events.on("routeChangeStart", ()=>{
        setLoading(true);
    });
    router_.Router.events.on("routeChangeComplete", ()=>{
        setLoading(false);
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "viewport",
                    content: "initial-scale=1.0, width=device-width"
                })
            }),
            loading && /*#__PURE__*/ jsx_runtime_.jsx(components_loading, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664], () => (__webpack_exec__(8341)));
module.exports = __webpack_exports__;

})();