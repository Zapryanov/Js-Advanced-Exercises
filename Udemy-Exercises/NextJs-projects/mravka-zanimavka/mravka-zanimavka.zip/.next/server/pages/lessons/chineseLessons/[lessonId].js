"use strict";
(() => {
var exports = {};
exports.id = 38;
exports.ids = [38];
exports.modules = {

/***/ 5699:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5771);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_loadable_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _data_getData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8546);
/* harmony import */ var _components_lessons_current_lesson_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);





const LoadableComponent = _loadable_component__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 902).then(__webpack_require__.bind(__webpack_require__, 1902))
);
function CurrentChineseLesson(props) {
    const { lesson  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    function goBack() {
        router.push("/lessons/chineseLessons");
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_lessons_current_lesson_component__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        language: lesson.language,
        title: lesson.title,
        image: lesson.image,
        cleanText: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoadableComponent, {
            text: lesson.text
        }),
        goBackFunc: goBack
    }));
}
async function getStaticProps({ params  }) {
    const currentLesson = await (0,_data_getData__WEBPACK_IMPORTED_MODULE_3__/* .getCurrentChineseLesson */ .HI)(params.lessonId);
    if (!currentLesson) {
        return {
            notFound: true
        };
    }
    return {
        props: {
            lesson: currentLesson
        },
        revalidate: 1800
    };
}
async function getStaticPaths() {
    const data = await (0,_data_getData__WEBPACK_IMPORTED_MODULE_3__/* .getAllChineseLessons */ .lS)();
    const ids = data.map((lesson)=>lesson.id
    );
    const pathsWithParams = ids.map((id)=>({
            params: {
                lessonId: id
            }
        })
    );
    return {
        paths: pathsWithParams,
        fallback: "blocking"
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrentChineseLesson);


/***/ }),

/***/ 5771:
/***/ ((module) => {

module.exports = require("@loadable/component");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6109:
/***/ ((module) => {

module.exports = require("sanitize-html");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,546,915], () => (__webpack_exec__(5699)));
module.exports = __webpack_exports__;

})();