export async function getAllChineseLessons() {
    try {
        const res = await fetch(`${process.env.databaseUrl}/${process.env.currentDatabase}/${process.env.currentChineseDatabase}.json`)
        const data = await res.json()
        const loadedLessons = [];

        for (const key in data) {
            loadedLessons.push({
                id: key, 
                ...data[key]
            })
        }

        return loadedLessons.reverse();

    } catch(err) {
        console.error(err)
    }
}

export async function getCurrentChineseLesson(id) {
    const allLessons = await getAllChineseLessons();
    const currentLesson = allLessons.find(lesson => lesson.id === id);

    return currentLesson;
}

export async function getAllEnglishLessons() {
    try {
        const res = await fetch(`${process.env.databaseUrl}/${process.env.currentDatabase}/${process.env.currentEnglishDatabase}.json`)
        const data = await res.json();
        
        const loadedLessons = [];
        
        for (const key in data) {
            loadedLessons.push({
                id: key, 
                ...data[key]
            })
        }

        return loadedLessons.reverse();
    } catch(err) {
        console.error(err)
    }
    
}

export async function getCurrentEnglishLesson(id) {
    const allLessons = await getAllEnglishLessons();
    const currentLesson = allLessons.find(lesson => lesson.id === id);

    return currentLesson;
}

export async function getContactsInfo() {
    const response = await fetch(`${process.env.databaseUrl}/${process.env.currentDatabase}/contacts.json`);
    const data = await response.json();

    return data;
}

export async function getImagesMainPage() {
    const response = await fetch(`${process.env.databaseUrl}/${process.env.currentDatabase}/iconsMainPage.json`);
    const data = await response.json();

    return data;
}

export const sanitizeObj = {
    allowedTags: [ 'br', 'b', 'i', 'em', 'span', 'strong', 'a', 'p', 'div', 'h1', 'h2', 'h3', 'ul', 'li' ],
    allowedAttributes: {
      'a': [ 'href' ]
    },
    selfClosing: [ 'br', 'hr', 'link' ]
}
