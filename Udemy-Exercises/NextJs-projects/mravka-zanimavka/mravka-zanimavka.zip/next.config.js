const { PHASE_DEVELOPMENT_SERVER } = require("next/constants");

module.exports = (phase) => {
  if (phase === PHASE_DEVELOPMENT_SERVER) {
    return {
      env: {
        databaseURL: process.env.databaseURL,
        currentDatabase: process.env.currentDevDatabase,
        currentChineseDatabase: process.env.currentChineseDatabase,
        currentEnglishDatabase: process.env.currentEnglishDatabase,
      },
      reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 319, 359, 479, 639, 767, 979, 991, 1023],
      }
    }
  }

  return {
    env: {
      databaseURL: process.env.databaseURL,
      currentDatabase: process.env.currentDevDatabase,
      currentChineseDatabase: process.env.currentChineseDatabase,
      currentEnglishDatabase: process.env.currentEnglishDatabase,
    },
    reactStrictMode: true,
      images: {
        domains: ['localhost', 'res.cloudinary.com'],
        deviceSizes: [250, 319, 359, 479, 639, 767, 979, 991, 1023],
      }
  }
}
